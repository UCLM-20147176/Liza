namespace WinFormsApp1
{
    public partial class Commission2 : Form
    {
        public Commission2()
        {
            InitializeComponent();
        }

        private void lblcommission_Click(object sender, EventArgs e)
        {

        }
        public void setValues(double totalSale, double com, string percentage)
        {
           
            lblcommission.Text = percentage;
            lblpeso.Text = com.ToString("N2");
            lblfinal.Text = totalSale.ToString("N2");


        }
    }
}