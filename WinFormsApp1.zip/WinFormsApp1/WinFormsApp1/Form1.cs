namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncomputecommission_Click(object sender, EventArgs e)
        {
            double t1 = Convert.ToDouble(txtjanuary.Text);
            double t2 = Convert.ToDouble(txtfebruary.Text);
            double t3 = Convert.ToDouble(txtmarch.Text);
            double totalSale = t1 + t2 + t3;
            double com = 0;
            string percentage = " ";
            txttotalsales.Text = totalSale.ToString("N2");


            if (chb1.Checked) 
            {
                com = totalSale * 0.10;
                percentage = "10%";
              
            }
            else if (chb2.Checked)
            {
                com = totalSale * 0.15;
                percentage = "15%";
            }
            else if (chb3.Checked)
            {
                com = totalSale * 0.50;
                percentage = "50%";
            }
            else if (totalSale == 1500)
            {
                com = totalSale * 0.15 * 0.10;
            }
            else if (totalSale > 10000)
            {
                com = totalSale * 0.15 * 0.10 * 0.50;
            }

            Commission2 lol = new Commission2();
            lol.setValues(totalSale, com, percentage);
            lol.Show();


        }

        private void txttotalsales_TextChanged(object sender, EventArgs e)
        {

        }

        private void chb1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}